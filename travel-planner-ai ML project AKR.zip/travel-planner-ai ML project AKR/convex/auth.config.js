export default {
  providers: [
    {
      domain: process.env.CUSTOM_DOMAIN,
      applicationID: "convex",
    },
  ],
};
